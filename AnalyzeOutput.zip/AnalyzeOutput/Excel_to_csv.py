import pandas as pd

df = pd.read_excel(r'/Users/oweneskandari/Desktop/ThesisResults_OE_4_28.xlsx', sheet_name='Sheet1')
df.to_csv('/Users/oweneskandari/Desktop/ThesisResults_OE_4_48.csv')


# python /Users/oweneskandari/PycharmProjects/21X/rl_pulse/22S/Excel_to_csv.py

